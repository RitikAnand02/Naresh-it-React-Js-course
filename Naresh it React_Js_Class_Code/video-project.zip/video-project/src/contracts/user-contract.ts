
export interface UserContract
{
    userid:string;
    username:string;
    password:string;
    email:string;
}