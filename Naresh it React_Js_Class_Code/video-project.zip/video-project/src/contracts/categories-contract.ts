
export interface CategoriesContract
{
    category_id:number;
    category_name:string;
}