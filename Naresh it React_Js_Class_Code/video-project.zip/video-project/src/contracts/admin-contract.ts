export interface AdminContract
{
    admin_id:string;
    password:string;
}