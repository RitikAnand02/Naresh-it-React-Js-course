
export function RegisterUser(){
    return(
        <div>
            <h3>Register User</h3>
        </div>
    )
}