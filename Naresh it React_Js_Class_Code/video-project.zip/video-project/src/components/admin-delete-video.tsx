

export function AdminDeleteVideo(){
    return(
        <div>
            <h3>Delete Video</h3>
        </div>
    )
}